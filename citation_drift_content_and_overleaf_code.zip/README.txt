This pack contains:
1. paper_content_for_humanizing.txt — manuscript text in plain form for humanizing/editing.
2. main.tex — IEEE conference-style Overleaf source for the same manuscript.

To use:
- Humanize/edit the plain text first.
- Send the revised content back to ChatGPT.
- Ask for the Overleaf LaTeX source using the same section order, tables, and results.
- Or upload main.tex directly to Overleaf as the current draft.

Important: The manuscript accurately describes the current experiment as a preliminary SciFact claim-verification baseline, not a direct evaluation of citation drift in AI-generated summaries. It does not invent hardware, package versions, batch size, or model revision.
