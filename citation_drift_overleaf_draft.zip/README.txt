Overleaf-ready preliminary paper draft

Files:
- main.tex: IEEE conference-style LaTeX paper draft
- references.bib: BibTeX references for SciFact, SNLI, MultiNLI, DeBERTa and DeBERTa-v3

How to use:
1. In Overleaf, create a blank project.
2. Upload main.tex and references.bib.
3. Set main.tex as the main document.
4. Compile with pdfLaTeX + BibTeX (Overleaf default IEEE conference setup usually works).

Important:
- Replace [Author Name], affiliation, email, and acknowledgment placeholders.
- [TO VERIFY] marks missing experiment details.
- The paper explicitly states this is a preliminary SciFact claim-verification baseline, not a direct citation-drift benchmark.
- Review references and project-specific details before submission.
- Metrics are reported with distinct populations: 338 overall examples and 170 non-neutral examples.
